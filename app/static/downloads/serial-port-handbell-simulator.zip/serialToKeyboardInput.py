import os
import sys
import time
import json
import pynput

from pynput.keyboard import Key, Controller

try:
    import serial
except ImportError:
    pass # still want to let people know this is a problem later if they try to use a serial port

with open("bell_config.json") as f:
    bell_config = json.load(f)

RING_LEFT = 10
RING_RIGHT = 20
RING_SIGNAL1 = 21
RING_SIGNAL2 = 22
RING_SIGNAL3 = 23
RING_SIGNAL4 = 24
ESCAPE = 30
STAND = 40

SERIAL = "serial"

class SerialInputter:
    def __init__(self):
        self.ser = serial.Serial()
        self.ser.port = bell_config['serial_port']
        self.ser.open()
        
        self.useCts = self.useDsr = self.useRi = self.useCd = False
        useConfig = bell_config['signal_map']
        if useConfig[0] > 0:
            self.useCts = True
        if useConfig[1] > 0:
            self.useDsr = True
        if useConfig[2] > 0:
            self.useRi = True
        if useConfig[3] > 0:
            self.useCd = True

        self.currentCts = self.ser.cts
        self.currentDsr = self.ser.dsr
        self.currentRi = self.ser.ri
        self.currentCd = self.ser.cd
    
    def get_input(self):
        ser = self.ser
        while True:
            if (self.useCts and ser.cts != self.currentCts):
                self.currentCts = ser.cts
                return RING_SIGNAL1
            if (self.useDsr and ser.dsr != self.currentDsr):
                self.currentDsr = ser.dsr
                return RING_SIGNAL2
            if (self.useRi and ser.ri != self.currentRi):
                self.currentRi = ser.ri
                return RING_SIGNAL3
            if (self.useCd and ser.cd != self.currentCd):
                self.currentCd = ser.cd
                return RING_SIGNAL4


class Client:

    def __init__(self):
        self.inputter = SerialInputter()

        self.keyboard = Controller()
        self.sendMsg() 


    def sendMsg(self):
        signal_map = bell_config['signal_map']
        if signal_map[0] > 0:
            bell_signal1 = chr(0x30 + signal_map[0])
        if signal_map[1] > 0:
            bell_signal2 = chr(0x30 + signal_map[1])
        if signal_map[2] > 0:
            bell_signal3 = chr(0x30 + signal_map[2])
        if signal_map[3] > 0:
            bell_signal4 = chr(0x30 + signal_map[3])

        while True:
            input_value = self.inputter.get_input()
            if input_value == RING_SIGNAL1:
                currentBellSignal = bell_signal1
            if input_value == RING_SIGNAL2:
                currentBellSignal = bell_signal2
            if input_value == RING_SIGNAL3:
                currentBellSignal = bell_signal3
            if input_value == RING_SIGNAL4:
                currentBellSignal = bell_signal4

            self.keyboard.press(currentBellSignal)
            time.sleep(.001)
            self.keyboard.release(currentBellSignal)
            
           


client = Client()
